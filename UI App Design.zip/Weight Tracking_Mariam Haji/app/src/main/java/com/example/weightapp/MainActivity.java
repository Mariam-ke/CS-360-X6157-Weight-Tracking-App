package com.example.weightapp;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    // Method to handle successful login and open the main_screen activity
    private void loginSuccess(View view) {
        Intent intent = new Intent(this, main_screen.class);
        startActivity(intent);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main); // Set the layout for this activity from activity_main.xml

        // Initialize the EditText fields and the login button from the layout
        EditText username = findViewById(R.id.textUsername);
        EditText password = findViewById(R.id.textPassword);
        Button loginbtn = findViewById(R.id.buttonLogin);

        // Set the click listener for the login button
        // When the button is clicked, the following code will be executed
        loginbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Check if the entered username and password match the correct values (admin and pass)
                if (username.getText().toString().equals("admin") && password.getText().toString().equals("pass")) {
                    // If the login is correct, call the loginSuccess method to open the main_screen activity
                    loginSuccess(v);
                } else {
                    // If the login is incorrect, show a toast message indicating the failure
                    Toast.makeText(MainActivity.this, "LOGIN FAILED !!!", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
