package com.example.weightapp;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class data_display extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.data_display); // Set the layout for this activity from the data_display.xml file.
    }

    // This method is called when the "Add Weight" button is clicked in the data_display.xml layout.
    public void openWeightForm(View view){
        Intent intent = new Intent(this, weightEntry.class); // Create a new Intent to navigate to the weightEntry activity.
        startActivity(intent); // Start the weightEntry activity using the Intent.
    }
}
