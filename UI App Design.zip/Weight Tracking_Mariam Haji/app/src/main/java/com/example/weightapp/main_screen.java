package com.example.weightapp;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

public class main_screen extends AppCompatActivity {

    // Method to create the options menu in the action bar
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.app_menu, menu); // Inflate the menu layout (app_menu.xml) into the menu object
        return true; // Return true to indicate that the menu was successfully created
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.data_display_main); // Set the layout for this activity from data_display_main.xml

        Button editBtn = findViewById(R.id.buttonEditWeight); // Find the "Edit Weight" button in the layout
    }

    // Method to handle menu item selection in the action bar
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.user_setting) { // Check if the selected menu item is the "Settings" option
            openSettings(); // If "Settings" is selected, call the openSettings method to open the userSettings activity
            return true; // Return true to indicate that the item selection was handled
        }
        return super.onOptionsItemSelected(item); // If the selected menu item is not handled here, pass it to the superclass for default behavior
    }

    // Method to open the userSettings activity
    public void openSettings() {
        Intent intent = new Intent(this, userSettings.class); // Create an intent to start the userSettings activity
        startActivity(intent); // Start the activity specified by the intent
    }

    // Method to open the data_display activity (used for "Edit Weight" button click)
    public void openEdit(View view) {
        Intent intent = new Intent(this, data_display.class); // Create an intent to start the data_display activity
        startActivity(intent); // Start the activity specified by the intent
    }

    // Method to open the weightEntry activity (used for "Floating Add Weight" button click)
    public void openWeightForm(View view) {
        Intent intent = new Intent(this, weightEntry.class); // Create an intent to start the weightEntry activity
        startActivity(intent); // Start the activity specified by the intent
    }
}
