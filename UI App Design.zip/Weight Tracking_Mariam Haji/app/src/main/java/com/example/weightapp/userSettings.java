package com.example.weightapp;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

public class userSettings extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.user_settings); // Set the layout for this activity from the user_settings.xml file.
    }
}
