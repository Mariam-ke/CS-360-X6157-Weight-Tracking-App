package com.example.weightapp;

import androidx.appcompat.app.AppCompatActivity;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import java.util.Calendar;

public class weightEntry extends AppCompatActivity {

    protected EditText dateEntry; // EditText to capture the weight entry date.

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.weight_entry); // Set the layout for this activity from the weight_entry.xml file.

        dateEntry = findViewById(R.id.editWeightDate); // Find the EditText with ID "editWeightDate" from the layout.

        // Set a click listener on the dateEntry EditText to show the DatePickerDialog when clicked.
        dateEntry.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                // Create an instance for the Calendar.
                final Calendar c = Calendar.getInstance();

                // Get the current day, month, and year.
                int year = c.get(Calendar.YEAR);
                int month = c.get(Calendar.MONTH);
                int day = c.get(Calendar.DAY_OF_MONTH);

                // Create a DatePickerDialog with the current date as default and set the date selected listener.
                DatePickerDialog datePickerDialog = new DatePickerDialog(
                        // Pass the current activity context.
                        weightEntry.this,
                        new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker view, int year,
                                                  int monthOfYear, int dayOfMonth) {
                                // Set the selected date to the dateEntry EditText in the format (MM-DD-YYYY).
                                dateEntry.setText((monthOfYear + 1) + "-" + dayOfMonth  + "-" + year);
                            }
                        },
                        // Set the year, month, and day for the DatePicker to display the current date as default.
                        year, month, day);
                // Show the DatePickerDialog to the user.
                datePickerDialog.show();
            }
        });
    }

    // This method is called when the "Open Main Form" button is clicked in the weight_entry.xml layout.
    public void openMainForm(View view){
        Intent intent = new Intent(this, main_screen.class); // Create a new Intent to navigate to the main_screen activity.
        startActivity(intent); // Start the main_screen activity using the Intent.
    }
}
